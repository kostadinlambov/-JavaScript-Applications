function startApp(){
    showHideMenuLinks();
    attachAllEvents();
}